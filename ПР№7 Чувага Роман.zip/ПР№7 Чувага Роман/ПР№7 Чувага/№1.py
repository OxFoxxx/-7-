def split_words(input_string):
    return input_string.split(": ")


def filter_and_format_words(words, min_length):

    filtered_words = [
        word.capitalize()
        for word in words
        if len(word) >= min_length and len(word) % 3 != 0]
    return filtered_words


def print_result(filtered_words):
    print(" - ".join(filtered_words))


def main():
    min_length = int(input("Введите число (минимальная длина слова): "))
    input_string = input("Введите строку слов через двоеточие и пробел: ")
    words = split_words(input_string)
    filtered_words = filter_and_format_words(words, min_length)
    print_result(filtered_words)


if __name__ == "__main__":
    main()