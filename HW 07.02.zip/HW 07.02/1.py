receipt_items = []
receipt_number = 1


def add_item(item_name, item_cost):
    global receipt_items
    receipt_items.append((item_name, item_cost))


def print_receipt():
    global receipt_items, receipt_number
    if not receipt_items:
        return
    total_cost = sum(item[1] for item in receipt_items)

    print(f"Чек {receipt_number}. Всего предметов: {len(receipt_items)}")
    for item in receipt_items:
        print(f"{item[0]} - {item[1]}")
    print(f"Итого: {total_cost}")
    print("-----")  # Черта для отрыва чека
    receipt_items = []
    receipt_number += 1

add_item("Блокнот", 100)
add_item("Ручка", 70)
print_receipt()  # Печать первого чека

add_item("Карандаш", 30)
add_item("Ластик", 20)
print_receipt()

print_receipt()