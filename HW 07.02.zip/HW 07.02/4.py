
MorseCode = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..',
    '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....',
    '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----',
    ' ': ' '}

ReverseMorseCode = {value: key for key, value in MorseCode.items()}

def encode_to_morse(text):
    encoded_text = []
    for char in text.upper():
        if char in MorseCode:
            encoded_text.append(MorseCode[char])
        else:
            encoded_text.append('')
    return ' '.join(encoded_text)

def decode_from_morse(code):
    decoded_text = []
    for morse_word in code.split(' '):
        if morse_word in ReverseMorseCode:
            decoded_text.append(ReverseMorseCode[morse_word])
        else:
            decoded_text.append('')
    return ''.join(decoded_text)

def main():
    while True:
        choice = input("Выберите действие: 1 - Закодировать текст, 2 - Декодировать код Морзе, 0 - Выйти: ")
        if choice == '1':
            text = input("Введите текст для кодирования: ")
            encoded_text = encode_to_morse(text)
            print(f"Закодированный текст: {encoded_text}")
        elif choice == '2':
            code = input("Введите код Морзе для декодирования: ")
            decoded_text = decode_from_morse(code)
            print(f"Декодированный текст: {decoded_text}")
        elif choice == '0':
            print("Выход из программы.")
            break
        else:
            print("Неверный выбор. Пожалуйста, выберите 1, 2 или 0.")

if __name__ == "__main__":
    main()