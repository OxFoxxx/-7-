translated_text = None


def translate(text):
    global translated_text
    vowels = "аеёиоуыэюяАЕЁИОУЫЭЮЯ"
    translated = []
    for char in text:
        if char not in vowels and char.isalpha() or char == " ":
            translated.append(char)
    translated_text = " ".join("".join(translated).split())

translated_text = None
translate("Удивительный факт, но текст на языке НЕРАЗБОРЧИВО оказывается довольно просто читать. Достаточно небольшой тренировки - и вы сможете это делать.")
print(translated_text)