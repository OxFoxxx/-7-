employee_name = None
vacation_dates = None

def setup_profile(name, dates):
    global employee_name, vacation_dates
    employee_name = name
    vacation_dates = dates

def print_application_for_leave():
    global employee_name, vacation_dates
    if not employee_name or not vacation_dates:
        print("Ошибка: данные работника не установлены.")
        return
    print(f"Заявление на отпуск в период {vacation_dates}. {employee_name}")

def print_holiday_money_claim(amount):
    global employee_name
    if not employee_name:
        print("Ошибка: данные работника не установлены.")
        return
    print(f"Прошу выплатить {amount} отпускных денег. {employee_name}")

def print_attorney_letter(to_whom):
    global employee_name, vacation_dates
    if not employee_name or not vacation_dates:
        print("Ошибка: данные работника не установлены.")
        return
    print(f"На время отпуска в период {vacation_dates} моим заместителем назначается {to_whom}. {employee_name}")

setup_profile("Иван Петров", "1 июня – 20 июня")
print_application_for_leave()
print_holiday_money_claim("15 тысяч пиастров")
print_attorney_letter("Василий Васильев")